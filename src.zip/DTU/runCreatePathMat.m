clear all;
dataSize = '1200x1600';
dtuDataSet = ['/media/malte/Storage/img' dataSize];
%dtuDataFormat = '%s/SET%.3d/Img%.3d_%.2d.bmp';
dtuDataFormat = '%s/scene%.3d/%.3d_%.2d.png';
dtuDataReconstructions = '/media/malte/Storage/reconstructions';
dtuResults = ['/media/malte/Storage/results' dataSize];
dtuCalibrationFile = [dtuDataSet '/calibrationFile'];

mitDataSet = '';
mitDataFormat = '%s/per%.5d.ppm';

inriaDataSet = '/media/malte/Storage/INRIAPerson';
inriaResults = [inriaDataSet '/results'];

clear dataSize;

save('DTU/paths');
