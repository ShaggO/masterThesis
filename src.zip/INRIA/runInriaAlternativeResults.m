clc, clear all

params = load('results/optimize/inriaParametersGo.mat');
logger1 = params.logger.data;
logger2 = params.loggerParameterResults.data;

logger2(12)
logger2(13)
logger2(14)
logger2(15)