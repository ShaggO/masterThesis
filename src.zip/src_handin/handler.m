classdef handler < handle

properties
    data
end

methods
    function obj = handler(data)
        obj.data = data;
    end
end

end