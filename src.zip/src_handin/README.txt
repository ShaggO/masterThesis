****************************************************************************
 Readme for the implementation of framework and descriptors for the thesis:
 "A study of higher order descriptors"
 By Benjamin Michael Braithwaite and Malte Stær Nissen

****************************************************************************

The code in this .zip-file contains the code developed during our work.
Everything is programmed in Matlab 2014a. The Liblinear library is included
in this .zip-file since we have re-names some of the functions to avoid
name-clashes with built in Matlab SVM functions. Furthermore we use functions
from the VLFeat v. 0.9.18 library, which is not included in this .zip-file.


The following is a list of essential folders and their contents:

./              General functions used in both applications
cellHist/       Implementation of our descriptor framework
detectors/      Detector wrappers and sliding window implementation
vl/             VLFeat wrappers for SIFT and HOG
DTU/            Framework for evaluating image correspondence on the DTU
                Robot 3D dataset
INRIA/          Framework for evaluating pedestrian detection on the INRIA
                Person dataset


------------

General comments:
All files with the prefix "run" are matlab scripts, which can be executed.
This however sometimes require multiple other scripts to be run and the
presence of the datasets. Please contact us if this is needed.

------------

The following folders contain code, which is NOT our product:
liblinear/              Liblinear library containing code for a linear svm
DTU/RobotEvalCode/      DTU evaluation code
figureTools/*/          Various plotting tools found at mathworks. All folders
                        contain a license.txt with the respective authors stated


In case you have any questions regarding the code and how to use it, please
contact one of us through e-mail:

Malte Stær Nissen
tgq958@alumni.ku.dk

Benjamin Michael Braithwaite
cpg608@alumni.ku.dk
