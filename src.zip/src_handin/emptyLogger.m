function logger = emptyLogger()

logger = struct('parameter',{},'iteration',{},'values',{},'PRAUC',{},'stdPRAUC',{},'dims',{});

end
