function m = methodStruct(det, detArgs, des, desArgs, cache, plotParams)

m.detector = det;
m.detectorArgs = detArgs;
m.descriptor = des;
m.descriptorArgs = desArgs;
m.cache = cache;
m.plotParams = plotParams;

end

